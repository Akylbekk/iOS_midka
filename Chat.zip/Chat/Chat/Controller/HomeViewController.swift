//
//  ViewController.swift
//  Chat
//
//  Created by Bagdat on 5/6/21.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

